# Testing Plan and Expected Results

## Reference test
- Reference string: `7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2`
- Frames: `3`

| Algorithm | Page Hits | Page Faults |
|---|---:|---:|
| FIFO | 3 | 10 |
| LRU | 4 | 9 |
| Optimal | 6 | 7 |

## Manual test cases
| Test | Input / action | Expected behavior |
|---|---|---|
| TC01 | Run the reference test with 3 frames | FIFO: 3 hits, 10 faults; LRU: 4 hits, 9 faults; Optimal: 6 hits, 7 faults |
| TC02 | Input `1,1,1`, frames 3 | First reference is a fault; next two are hits; total 1 fault and 2 hits for all algorithms |
| TC03 | Input `1,2,3,4`, frames 3 | Four distinct references cause 4 faults and 0 hits for all algorithms |
| TC04 | Input blank spaces | Validation message asks for a page-reference string |
| TC05 | Input `1,a,3` | Validation message explains that only non-negative whole numbers are allowed |
| TC06 | Set frames to 0 or more than 8 | Frame count validation should reject invalid values when Run is clicked |
| TC07 | Input `0,1,0`, frames 2 | Page ID zero is accepted; total 2 faults and 1 hit |
| TC08 | Input over 60 page references | Validation message asks for 60 or fewer references |

## Manual testing procedure
1. Run `npm install` and `npm run dev`.
2. Open the local Vite URL in a browser.
3. Test the reference test above and compare counts with the expected results.
4. Switch between FIFO, LRU, and Optimal. Confirm the timeline and statistics update.
5. Change the frame count and rerun.
6. Try invalid inputs and confirm readable validation messages.
7. Run `npm run build` and confirm that Vite completes without errors.

The expected counts above match the algorithm implementations included in this project. Re-run tests after modifying the code.
