# Virtual Memory Page Replacement Visualizer

**Batch:** 19  
**Project title:** Virtual Memory Page Replacement Visualizer  
**Stack:** React, CSS, JavaScript, Vite

## Overview
An interactive educational website that simulates FIFO, LRU, and Optimal page replacement. Users enter a page-reference string and frame count, then inspect memory-frame changes, hits, faults, ratios, and an algorithm comparison.

## Requirements
- Node.js 18 or later (Node.js 20 LTS recommended)
- npm
- VS Code (recommended)
- Internet connection only for the optional Google Fonts import; the app logic works locally

## Run locally
1. Install Node.js from https://nodejs.org/
2. Extract this project ZIP.
3. Open the extracted folder in VS Code.
4. Open Terminal → New Terminal.
5. Run `npm install`.
6. Run `npm run dev`.
7. Open the local URL printed by Vite, usually `http://localhost:5173`.
8. Enter page references such as `7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2`, choose a frame count, and click **Run simulation**.

## Build for production
```bash
npm run build
npm run preview
```
The production website is created in the `dist/` folder.

## Algorithms
- **FIFO:** evicts the page that entered memory earliest.
- **LRU:** evicts the page whose most recent use is oldest.
- **Optimal:** evicts the page whose next use is farthest in the future (or is never used again).

## Input rules
- Non-negative whole-number page IDs, separated by commas or spaces.
- 1–60 page references.
- 1–8 memory frames.

## Test cases
See `docs/test-cases.md` for sample tests and expected counts.

## GitHub setup
1. Create a new public repository named `virtual-memory-page-replacement-visualizer`.
2. In the project folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial page replacement visualizer"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/virtual-memory-page-replacement-visualizer.git
   git push -u origin main
   ```
3. Replace `YOUR-USERNAME` with your GitHub username. Do not submit the placeholder URL.
4. Copy the real repository URL into your report and PPT.

## Deploy with Vercel
1. Push the project to GitHub.
2. Sign in to https://vercel.com/ and import the repository.
3. Framework preset: **Vite**.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Click Deploy and use the generated URL in your submission.

Alternative: deploy to GitHub Pages after configuring Vite's `base` path for the repository name.

## Suggested team contributions
- Yegna Sai Reddy: frontend layout and visualization (suggested role)
- Sonu: algorithm logic and verification (suggested role)
- Suresh Babu: test cases, documentation, repository and deployment integration (suggested role)

Update these roles to match actual contributions.

## Limitations and future scope
- Optimal is a theoretical benchmark and requires future-reference knowledge.
- The application is an educational simulator, not a replacement for an operating system's memory manager.
- Future additions may include Clock, Second-Chance, animation controls, CSV export, and saved sessions.
