import React, { useMemo, useState } from "react";
import { Activity, ArrowRight, CheckCircle2, CircleHelp, Cpu, RotateCcw, Sparkles } from "lucide-react";
import { parsePages, runAlgorithm } from "./algorithms";

const ALGORITHMS = [
  { id: "FIFO", name: "FIFO", full: "First In, First Out", description: "Replaces the page that entered memory earliest." },
  { id: "LRU", name: "LRU", full: "Least Recently Used", description: "Replaces the page that has not been used for the longest time." },
  { id: "OPTIMAL", name: "Optimal", full: "Optimal Replacement", description: "Replaces the page whose next use is farthest in the future." }
];

export default function App() {
  const [referenceInput, setReferenceInput] = useState("7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2");
  const [frameCount, setFrameCount] = useState(3);
  const [selected, setSelected] = useState("FIFO");
  const [error, setError] = useState("");
  const [showAll, setShowAll] = useState(true);
  const [showResults, setShowResults] = useState(true);

  const pages = useMemo(() => {
    try { return parsePages(referenceInput); } catch { return []; }
  }, [referenceInput]);

  const results = useMemo(() => {
    if (!pages.length || frameCount < 1) return [];
    return ALGORITHMS.map(item => runAlgorithm(pages, Number(frameCount), item.id));
  }, [pages, frameCount]);

  const activeResult = results.find(result => result.algorithm === selected);

  function runSimulation() {
    try {
      parsePages(referenceInput);
      if (!Number.isInteger(Number(frameCount)) || Number(frameCount) < 1 || Number(frameCount) > 8) {
        throw new Error("Frame count must be an integer from 1 to 8.");
      }
      setError("");
      setShowResults(true);
    } catch (e) {
      setError(e.message);
      setShowResults(false);
    }
  }

  function reset() {
    setReferenceInput("7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2");
    setFrameCount(3);
    setSelected("FIFO");
    setError("");
    setShowAll(true);
    setShowResults(true);
  }

  const selectedAlgorithm = ALGORITHMS.find(item => item.id === selected);

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="Page Replacement Visualizer home">
          <span className="brand-mark"><Cpu size={21} /></span>
          <span>Memory<span className="brand-light">Lab</span></span>
        </a>
        <div className="topbar-right"><span className="status-dot" /> OS Learning Studio <span className="version">v1.0</span></div>
      </header>

      <main className="main">
        <section className="hero">
          <div className="eyebrow"><Sparkles size={14} /> OPERATING SYSTEMS · INTERACTIVE LAB</div>
          <h1>Page Replacement <span>Visualizer</span></h1>
          <p className="hero-copy">See how virtual memory works. Compare page replacement algorithms, track page faults, and understand every frame change.</p>
          <div className="hero-tags"><span>FIFO</span><span>LRU</span><span>OPTIMAL</span><span className="tag-muted">No backend required</span></div>
        </section>

        <section className="control-panel panel">
          <div className="section-heading">
            <div><div className="section-kicker">01 / CONFIGURE</div><h2>Simulation setup</h2></div>
            <button className="btn btn-ghost" onClick={reset}><RotateCcw size={15} /> Reset</button>
          </div>
          <div className="form-grid">
            <label className="field field-pages">
              <span>Page-reference string</span>
              <input value={referenceInput} onChange={e => setReferenceInput(e.target.value)} onKeyDown={e => e.key === "Enter" && runSimulation()} placeholder="e.g. 1, 2, 3, 1, 4, 5" />
              <small>Separate page numbers with commas or spaces. Maximum 60 references.</small>
            </label>
            <label className="field">
              <span>Memory frames</span>
              <select value={frameCount} onChange={e => setFrameCount(Number(e.target.value))}>
                {[1,2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} {n === 1 ? "frame" : "frames"}</option>)}
              </select>
              <small>Number of page slots in RAM.</small>
            </label>
          </div>
          <div className="algorithm-label">Choose algorithm</div>
          <div className="algorithm-grid">
            {ALGORITHMS.map(item => (
              <button key={item.id} className={`algorithm-card ${selected === item.id ? "selected" : ""}`} onClick={() => setSelected(item.id)}>
                <span className="radio-dot">{selected === item.id && <span />}</span>
                <span className="algo-name">{item.name}</span>
                <span className="algo-full">{item.full}</span>
                <span className="algo-desc">{item.description}</span>
              </button>
            ))}
          </div>
          {error && <div className="error-message" role="alert"><CircleHelp size={17} /> {error}</div>}
          <div className="run-row">
            <div className="input-summary"><span className="summary-dot" /> {pages.length || 0} page references loaded</div>
            <button className="btn btn-primary" onClick={runSimulation}>Run simulation <ArrowRight size={17} /></button>
          </div>
        </section>

        {showResults && activeResult && (
          <>
            <section className="stats-grid">
              <StatCard label="Page references" value={activeResult.steps.length} detail="Total requests" icon={<Activity size={18} />} />
              <StatCard label="Page hits" value={activeResult.hits} detail="Already in memory" icon={<CheckCircle2 size={18} />} accent="green" />
              <StatCard label="Page faults" value={activeResult.faults} detail="Page must be loaded" icon={<CircleHelp size={18} />} accent="orange" />
              <StatCard label="Hit ratio" value={`${activeResult.hitRatio.toFixed(1)}%`} detail={`${activeResult.faultRatio.toFixed(1)}% fault ratio`} icon={<Sparkles size={18} />} accent="blue" />
            </section>

            <section className="panel visualization-panel">
              <div className="section-heading">
                <div><div className="section-kicker">02 / VISUALIZE</div><h2>Memory frame timeline</h2><p className="section-subtitle">{selectedAlgorithm.full}: {selectedAlgorithm.description}</p></div>
                <div className="legend"><span><i className="legend-hit" /> Hit</span><span><i className="legend-fault" /> Fault</span></div>
              </div>
              <div className="timeline-toolbar">
                <span className="timeline-label">PAGE REFERENCE ORDER</span>
                <label className="toggle-label"><input type="checkbox" checked={showAll} onChange={e => setShowAll(e.target.checked)} /> Show all steps</label>
              </div>
              <div className="timeline-scroll">
                <div className="timeline" style={{ "--step-count": showAll ? activeResult.steps.length : Math.min(8, activeResult.steps.length) }}>
                  <div className="timeline-row page-row"><div className="row-label">Page</div>{(showAll ? activeResult.steps : activeResult.steps.slice(0,8)).map((step,i) => <div className="page-cell" key={i}>{step.page}</div>)}</div>
                  {Array.from({length: Number(frameCount)}, (_, frameIndex) => (
                    <div className="timeline-row" key={frameIndex}><div className="row-label">Frame {frameIndex + 1}</div>
                      {(showAll ? activeResult.steps : activeResult.steps.slice(0,8)).map((step,i) => <div className={`frame-cell ${step.hit ? "cell-hit" : "cell-fault"}`} key={i}>{step.frames[frameIndex] ?? "—"}</div>)}
                    </div>
                  ))}
                  <div className="timeline-row status-row"><div className="row-label">Status</div>{(showAll ? activeResult.steps : activeResult.steps.slice(0,8)).map((step,i) => <div className={`status-cell ${step.hit ? "text-hit" : "text-fault"}`} key={i}>{step.hit ? "HIT" : "FAULT"}</div>)}</div>
                </div>
              </div>
              {!showAll && activeResult.steps.length > 8 && <p className="hint">Showing the first 8 steps. Select “Show all steps” to view the complete timeline.</p>}
              <div className="timeline-note"><span className="note-mark">i</span><span>Each column represents one page request. A <b>fault</b> means the requested page was not in memory; a <b>hit</b> means it was already loaded.</span></div>
            </section>

            <section className="panel step-panel">
              <div className="section-heading"><div><div className="section-kicker">03 / STEP DETAILS</div><h2>What happened at each step?</h2></div></div>
              <div className="step-table-wrap">
                <table><thead><tr><th>Step</th><th>Requested page</th><th>Memory after request</th><th>Result</th><th>Replacement</th></tr></thead>
                  <tbody>{activeResult.steps.map(step => <tr key={step.index}><td>{step.index + 1}</td><td><span className="page-pill">{step.page}</span></td><td><div className="mini-frames">{Array.from({length:Number(frameCount)},(_,i)=><span key={i}>{step.frames[i] ?? "—"}</span>)}</div></td><td><span className={`result-pill ${step.hit ? "hit-pill" : "fault-pill"}`}>{step.hit ? "Hit" : "Fault"}</span></td><td>{step.replaced === null ? <span className="muted">None</span> : <span className="replace-text">{step.replaced} <ArrowRight size={12} /> {step.page}</span>}</td></tr>)}</tbody>
                </table>
              </div>
            </section>

            <section className="panel compare-panel">
              <div className="section-heading"><div><div className="section-kicker">04 / COMPARE</div><h2>Algorithm comparison</h2><p className="section-subtitle">Same input and frame count for a fair comparison.</p></div></div>
              <div className="comparison-grid">{results.map(result => <div className={`comparison-card ${result.algorithm === selected ? "comparison-active" : ""}`} key={result.algorithm} onClick={() => setSelected(result.algorithm)} role="button" tabIndex={0} onKeyDown={e => e.key === "Enter" && setSelected(result.algorithm)}>
                <div className="compare-top"><span>{result.algorithm === "OPTIMAL" ? "OPTIMAL" : result.algorithm}</span>{result.algorithm === "OPTIMAL" && <span className="best-badge">Reference</span>}</div>
                <div className="compare-faults">{result.faults}<small> faults</small></div>
                <div className="bar-track"><div className="bar-fill" style={{width:`${result.steps.length ? result.faults/result.steps.length*100 : 0}%`}} /></div>
                <div className="compare-bottom"><span>{result.hits} hits</span><span>{result.hitRatio.toFixed(1)}% hit ratio</span></div>
              </div>)}</div>
              <p className="comparison-footnote">Optimal provides a theoretical benchmark because it uses knowledge of future page requests. Real operating systems cannot generally know future requests exactly.</p>
            </section>
          </>
        )}
        <footer><div className="footer-brand"><span className="brand-mark small"><Cpu size={15}/></span> MemoryLab</div><span>Virtual Memory Page Replacement Visualizer · Batch 19</span><span>Built for learning Operating Systems</span></footer>
      </main>
    </div>
  );
}

function StatCard({label,value,detail,icon,accent=""}) {
  return <div className={`stat-card ${accent}`}><div className="stat-top"><span>{label}</span><span className="stat-icon">{icon}</span></div><div className="stat-value">{value}</div><div className="stat-detail">{detail}</div></div>;
}