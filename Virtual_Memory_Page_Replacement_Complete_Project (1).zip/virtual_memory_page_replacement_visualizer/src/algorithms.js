// Each algorithm returns a step for every page reference.
// A step contains the frame state, whether it was a hit, and the page removed.
export function runAlgorithm(referenceString, frameCount, algorithm) {
  const pages = referenceString.map(Number);
  const frames = [];
  const steps = [];
  const lastUsed = new Map();
  const loadOrder = new Map();
  let loadCounter = 0;

  pages.forEach((page, index) => {
    const hit = frames.includes(page);
    let replaced = null;

    if (!hit) {
      if (frames.length < frameCount) {
        frames.push(page);
        loadOrder.set(page, loadCounter++);
      } else {
        let victimIndex = 0;

        if (algorithm === "FIFO") {
          victimIndex = frames.reduce((best, value, i) =>
            loadOrder.get(value) < loadOrder.get(frames[best]) ? i : best, 0);
        } else if (algorithm === "LRU") {
          victimIndex = frames.reduce((best, value, i) =>
            (lastUsed.get(value) ?? -1) < (lastUsed.get(frames[best]) ?? -1) ? i : best, 0);
        } else if (algorithm === "OPTIMAL") {
          let farthestNextUse = -1;
          frames.forEach((value, i) => {
            const next = pages.slice(index + 1).indexOf(value);
            const distance = next === -1 ? Infinity : next;
            if (distance > farthestNextUse) {
              farthestNextUse = distance;
              victimIndex = i;
            }
          });
        }

        replaced = frames[victimIndex];
        frames[victimIndex] = page;
        loadOrder.delete(replaced);
        loadOrder.set(page, loadCounter++);
      }
    }

    lastUsed.set(page, index);
    steps.push({
      page,
      frames: [...frames],
      hit,
      replaced,
      index,
      status: hit ? "HIT" : "FAULT"
    });
  });

  const hits = steps.filter(step => step.hit).length;
  const faults = steps.length - hits;
  return {
    algorithm,
    steps,
    hits,
    faults,
    hitRatio: steps.length ? (hits / steps.length) * 100 : 0,
    faultRatio: steps.length ? (faults / steps.length) * 100 : 0
  };
}

export function parsePages(value) {
  const trimmed = value.trim();
  if (!trimmed) throw new Error("Enter a page-reference string.");
  const tokens = trimmed.split(/[,\s]+/).filter(Boolean);
  if (!tokens.every(token => /^\d+$/.test(token))) {
    throw new Error("Use non-negative whole numbers separated by commas or spaces.");
  }
  const pages = tokens.map(Number);
  if (pages.length > 60) throw new Error("Use 60 or fewer page references for this demo.");
  return pages;
}