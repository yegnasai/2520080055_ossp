const http = require("http");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");

const PORT = 8080;
const ROOT = __dirname;
const BINARY = path.join(ROOT, "fileio");

const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://localhost:${PORT}`);

    if (req.method === "GET" && url.pathname === "/") {
        return sendFile(res, "index.html", "text/html; charset=utf-8");
    }
    if (req.method === "GET" && url.pathname === "/style.css") {
        return sendFile(res, "style.css", "text/css; charset=utf-8");
    }

    if (req.method === "GET" && url.pathname === "/api") {
        const operation = url.searchParams.get("operation") || "";
        const filename = url.searchParams.get("filename") || "";
        const data = url.searchParams.get("data") || "";
        const allowed = ["create", "write", "read", "append", "seek", "close"];

        // Keep demo files inside this project folder.
        if (!allowed.includes(operation)) {
            return sendJson(res, 400, { success: false, output: "Invalid operation." });
        }
        if (!filename || filename !== path.basename(filename) || filename.includes("..")) {
            return sendJson(res, 400, { success: false, output: "Enter a simple file name, such as test.txt." });
        }
        if (["write", "append"].includes(operation) && !data) {
            return sendJson(res, 400, { success: false, output: "Please enter data first." });
        }

        const args = [operation, filename];
        if (["write", "append"].includes(operation)) args.push(data);

        return execFile(BINARY, args, { cwd: ROOT }, (error, stdout, stderr) => {
            const output = stdout || stderr || (error ? error.message : "Operation completed.");
            sendJson(res, error ? 400 : 200, { success: !error, output });
        });
    }

    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Not Found");
});

function sendFile(res, name, contentType) {
    fs.readFile(path.join(ROOT, name), (err, content) => {
        if (err) return sendJson(res, 500, { success: false, output: "Could not load page." });
        res.writeHead(200, { "Content-Type": contentType });
        res.end(content);
    });
}

function sendJson(res, status, body) {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(body));
}

server.listen(PORT, "127.0.0.1", () => {
    console.log(`Open http://localhost:${PORT} in your browser`);
});
