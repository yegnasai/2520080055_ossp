#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: ./fileio <operation> <filename> [data]\n");
        return 1;
    }

    const char *operation = argv[1];
    const char *filename = argv[2];
    int fd;
    char buffer[1024];
    ssize_t bytes;

    if (strcmp(operation, "create") == 0) {
        fd = open(filename, O_CREAT | O_RDWR, 0644);
        if (fd == -1) { perror("open"); return 1; }
        printf("File created/opened successfully!\nFile Descriptor: %d\n", fd);
        close(fd);
    }
    else if (strcmp(operation, "write") == 0) {
        if (argc < 4) { printf("Data required.\n"); return 1; }
        fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd == -1) { perror("open"); return 1; }
        printf("File Descriptor: %d\n", fd);
        bytes = write(fd, argv[3], strlen(argv[3]));
        if (bytes == -1) perror("write");
        else printf("Data written successfully!\nBytes written: %ld\n", (long)bytes);
        close(fd);
    }
    else if (strcmp(operation, "read") == 0) {
        fd = open(filename, O_RDONLY);
        if (fd == -1) { perror("open"); return 1; }
        printf("File Descriptor: %d\n", fd);
        bytes = read(fd, buffer, sizeof(buffer) - 1);
        if (bytes == -1) perror("read");
        else {
            buffer[bytes] = '\0';
            printf("File Contents:\n%s\nBytes read: %ld\n", buffer, (long)bytes);
        }
        close(fd);
    }
    else if (strcmp(operation, "append") == 0) {
        if (argc < 4) { printf("Data required.\n"); return 1; }
        fd = open(filename, O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (fd == -1) { perror("open"); return 1; }
        printf("File Descriptor: %d\n", fd);
        bytes = write(fd, argv[3], strlen(argv[3]));
        if (bytes == -1) perror("write");
        else printf("Data appended successfully!\nBytes appended: %ld\n", (long)bytes);
        close(fd);
    }
    else if (strcmp(operation, "seek") == 0) {
        fd = open(filename, O_RDONLY);
        if (fd == -1) { perror("open"); return 1; }
        printf("File Descriptor: %d\n", fd);
        off_t position = lseek(fd, 5, SEEK_SET);
        if (position == (off_t)-1) perror("lseek");
        else printf("File pointer moved to position: %ld\n", (long)position);
        close(fd);
    }
    else if (strcmp(operation, "close") == 0) {
        fd = open(filename, O_RDONLY);
        if (fd == -1) { perror("open"); return 1; }
        printf("File Descriptor: %d\n", fd);
        if (close(fd) == 0) printf("File closed successfully!\n");
        else perror("close");
    }
    else {
        printf("Invalid operation.\n");
        return 1;
    }
    return 0;
}
