# Linux File I/O Management System

A beginner-friendly Operating Systems project that demonstrates Linux file handling through C system calls and a browser-based interface.

## Features

- Create or open a file
- Write data (overwrite existing contents)
- Read file contents
- Append data
- Move the file pointer using `lseek()`
- Close a file
- Display the file descriptor and operation output in the browser

## Technology

- C and Linux system calls: `open()`, `read()`, `write()`, `lseek()`, `close()`
- GCC compiler
- Node.js built-in HTTP server
- HTML, CSS and JavaScript
- Ubuntu Linux

## Requirements

Use Ubuntu Linux or WSL with Ubuntu. Install GCC and Node.js:

```bash
sudo apt update
sudo apt install build-essential nodejs npm -y
```

## Run the project

Open a terminal in this project folder.

1. Compile the C program:

```bash
gcc fileio.c -o fileio
```

2. Start the local web server:

```bash
node server.js
```

3. Open this address in Firefox or Chrome:

```text
http://localhost:8080
```

Keep the terminal running while using the website. Press `Ctrl+C` in the terminal to stop the server.

## Try these operations

1. Keep the file name as `test.txt`.
2. Click **Create / Open**.
3. Enter text in the data box and click **Write**.
4. Click **Read** to display the contents.
5. Enter more text and click **Append**.
6. Click **Read** again to see the appended text.
7. Click **lseek** to move the file pointer to byte position 5.
8. Click **Close**.

Files created by the demo are stored in this project folder. Use a simple file name such as `test.txt`; do not enter a directory path.

## Important note about file descriptors

Linux normally uses descriptors 0, 1 and 2 for standard input, standard output and standard error. A newly opened file commonly receives descriptor 3. This program opens and closes the file during each operation, so the same descriptor number may appear repeatedly.

## Project flow

Browser (HTML/CSS/JavaScript) → Node.js local server → compiled C program → Linux system calls → file.

This is a local classroom demonstration. Do not expose the server to a public network.
